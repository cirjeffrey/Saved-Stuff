///////////////////////////////////////////////////////////////////////////////
// sort_comparison.hpp
//
// Four sorting algorithms:
//
// - the builtin C/C++ sort
// - in-place selection sort
// - merge sort on linked lists
// - merge sort on vectors
//
///////////////////////////////////////////////////////////////////////////////

#pragma once

// standard library headers
#include <algorithm>
#include <fstream>
#include <iostream>
#include <list>
#include <memory>
#include <string>
#include <vector>

// user libraries
#include "json.hpp"

// aliases for a vector or list of strings
using StringVector = std::vector<std::string>;
using StringList = std::list<std::string>;

// Load strings from the JSON file at json_path. The JSON file must
// contain precisely one array object, where each element of the array
// is a string. Returns nullptr on I/O error or parse error.
std::unique_ptr<StringVector> load_json_string_array(const std::string& json_path) {

	// Null object to return in the event of error.
	std::unique_ptr<StringVector> io_failure(nullptr);

	// First, try to load a JSON file, whatever it might contain, into
	// root.
	nlohmann::json root;
	{
		// Open file.
		std::ifstream f(json_path);
		if (!f) {
			// file not found
			return io_failure;
		}

		// Parse JSON.
		f >> root;
		if (!f) {
			// JSON parse error
			f.close();
			return io_failure;
		}

		f.close();
		// We're done with the file, so don't need to worry about closing
		// it from now on.
	}

	// Check that the json object is actually an array of strings.
	if (!(root.is_array() &&
		std::all_of(root.begin(),
			root.end(),
			[&](const nlohmann::json& element) {
		return element.is_string();
	}))) {
		// We got a JSON object, but not the right type of JSON object.
		return io_failure;
	}

	// Now copy the strings out of root and into a StringVector.
	std::unique_ptr<StringVector> result(new StringVector());
	for (auto&& element : root) {
		result->push_back(element);
	}
	return result;
}

// Sort unsorted in-place, using std::sort or qsort.
void builtin_sort(StringVector& unsorted) {
	std::sort(unsorted.begin(), unsorted.end());
}

// Sort unsorted in-place, using selection sort.
void selection_sort(StringVector& unsorted) {
	int least_index;
	if (unsorted.size() > 1) {
		for (int i = 0; i < unsorted.size(); i++) {
			least_index = i;
			for (int j = i + 1; j < unsorted.size(); j++) {
				if (unsorted[j] < unsorted[least_index]) {
					least_index = j;
				}
			}
			swap(unsorted[least_index], unsorted[i]);
		}
	}

}


// Merge halves user created  function used to sort through the two vector halves passed in. 
std::unique_ptr<StringVector> merge_halves(const StringVector& L, const StringVector& R) {

	std::unique_ptr<StringVector>Result(new StringVector());

	int li, ri;
	li = ri = 0;									// int iterators created and set to 0

	while (li < L.size() && ri < R.size())						// loop runs while either iterator is not equal
	{										// to their vector's size
		if (L[li] <= R[ri])							// if current element in L is greater than R,
		{									// add element to result
			Result->push_back(L[li]);
			li++;
		}
		else									// else, add r element
		{
			Result->push_back(R[ri]);
			ri++;
		}
	}
	while (li < L.size())								// while loops add any lingering elements
	{
		Result->push_back(L[li]);
		li++;
	}
	while (ri < R.size())
	{
		Result->push_back(R[ri]);
		ri++;
	}
	return Result;
}

// Sort an unsorted vector using merge sort. Returns a vector
// containing the same elements as unsorted, but in nondecreasing
// order.
std::unique_ptr<StringVector> merge_sort_vector(const StringVector& unsorted) {

	// return if starting vector if size is <= 1
	if (unsorted.size() <= 1)
	{
		std::unique_ptr<StringVector>One(new StringVector());
		if(unsorted.size() == 0)
			return One;
		
		One->push_back(unsorted[0]);
		return One;
	}

	else {
		int half = (unsorted.size() + 1) / 2;

		std::unique_ptr<StringVector>L(new StringVector());				// vectors created
		std::unique_ptr<StringVector>R(new StringVector());
		std::unique_ptr<StringVector>Result(new StringVector());

		for (int i = 0; i < half; i++)							// for loop ran until halfway mark 
		{
			L->push_back(unsorted[i]);
		}

		for (int i = half; i < unsorted.size(); i++)
		{
			R->push_back(unsorted[i]);
		}

		L = merge_sort_vector(*L);							// vectors sorted recursively
		R = merge_sort_vector(*R);
		Result = merge_halves(*L, *R);
		return Result;
	}
}
// Merge halves user created  function used to sort through the two vector halves passed in. 
std::unique_ptr<StringList> merge_halves_list(const StringList& L, const StringList& R) {

	std::unique_ptr<StringList>Result(new StringList());

	StringList::const_iterator li, ri;
	li = L.begin();								// left and right iterators created and set to beginning
	ri = R.begin();								// of each respective lists

	while(li != L.end() && ri != R.end())					// while loop checks if either iterator is at the end of list
	{
		if (*li <= *ri) {						// if li iterator is larger, adds li to result
			Result->push_back(*li);
			li++;
		}
		else {								// else, adds ri element with respective iterators incremented
			Result->push_back(*ri);
			ri++;
		}
	}
	
	while (li != L.end())							// any leftover elements added until both iterators are at 
	{									// lists end
		Result->push_back(*li);
		li++;
	}
	while (ri != R.end())
	{
		Result->push_back(*ri);
		ri++;
	}
	return Result;
}

// Sort an unsorted linked list using merge sort. Returns a linked
// list containing the same elements as unsorted, but in nondecreasing
// order.
std::unique_ptr<StringList> merge_sort_list(const StringList& unsorted) {
	if (unsorted.size() <= 1) {						// list is empty or contains only one element
		std::unique_ptr<StringList>One(new StringList());		

		if (unsorted.empty()) {						// returns empty list
			return One;
		}

		One->push_front(unsorted.front());				// pushes first and only element
		return One;
	}
	else {
		std::unique_ptr<StringList>L(new StringList());			// 3 empty StringLists created
		std::unique_ptr<StringList>R(new StringList());
		std::unique_ptr<StringList>Result(new StringList());
		int half = (unsorted.size() + 1) / 2;				// halfway count found
		int i = 0;
		StringList::const_iterator iter;				


		for (iter = unsorted.begin(); i < half; ++iter,i++) {		// iterator set to beginning of unsorted link
			L->push_back(*iter);					// each loop increases iterator count until halfway reached
		}					

		for (iter; iter != unsorted.end(); ++iter) {			// iterator left at halfway mark after first for loop
			R->push_back(*iter);
		}

		L = merge_sort_list(*L);					// merge_sort_list called recursively
		R = merge_sort_list(*R);
		Result = merge_halves_list(*L, *R);				// Result list created using merge_halves_list function
		return Result;
	}
	
}
