# Project 3: constant factor vs efficiency class

Group members:

Cirjeffrey Baldomero cirjeffrey92@gmail.com

Alessandro Quezada sandroq95@gmail.com

Juan Carrera juan_m_carrera@csu.fullerton.edu

Abstract


In this project you will implement and analyze four sorting algorithms:

A sort function built-in to the C++ library
In-place selection sort
Merge sort operating on vectors
Merge sort operating on linked lists

The goal is to compare the performance impact of changing to an algorithm with a theoretically-better efficiency class; versus changing to an algorithm with the same efficiency class but different constant factors.
