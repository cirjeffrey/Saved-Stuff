# Project 4
Project 4: dynamic programming

Group members:

Cirjeffrey Baldomero cirjeffrey92@gmail.com

Alessandro Quezada sandroq95@gmail.com

Juan Carrera juan_m_carrera@csu.fullerton.edu

Abstract

In this project you will implement and analyze a dynamic programming algorithm for the same maximum protein problem that we attacked in project 2. This algorithm is superior to the greedy and exhaustive-search algorithms from project 2. The dynamic programming algorithm is perfectly correct, whereas the greedy algorithm’s heuristic can be “tricked” into picking a sub-optimal result. But the dynamic programming algorithm is also much faster than O(2n)-time exhaustive search algorithm. For an instance with n foods and calorie budget W, the dynamic programming algorithm runs in either O(nW) or O(n2W) time, depending on how you use data structures.


