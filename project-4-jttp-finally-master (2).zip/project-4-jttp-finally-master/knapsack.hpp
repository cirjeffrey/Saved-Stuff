///////////////////////////////////////////////////////////////////////////////
// knapsack.hpp
//
// Solve the maximum-protein-diet problem described in maxprotein.hh
// using dynamic programming.
//
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include <memory>
#include <vector>
#include "maxprotein.hh"


std::unique_ptr<FoodVector> knapsack_max_protein(const FoodVector& all_foods, int total_kcal) {
	assert(total_kcal >= 0);

	int n = all_foods.size();
	int w = total_kcal;
	std::vector<std::vector<FoodVector>> matrix;
	matrix.resize((n + 1), std::vector<FoodVector>(w + 1));
	FoodVector do_use, dont_use, soln;
	std::unique_ptr<FoodVector> solution(new FoodVector);

	if (all_foods.size() == 0) {
		return solution;
	}

	for (int i = 1; i <= n; i++){
		// all_foods[i - 1] can be used
		Food this_item = *(all_foods[i - 1]);
		for (int j = 0; j <= w; j++) {
			// old solution that does not include this_item
			dont_use = matrix[i - 1][j];
			// test if we have the budget for this_item
			if (this_item.kcal() > j) {
				// this item is too heavy, default to the previously known solution
				matrix[i][j] = matrix[i - 1][j];
			}
			else {
				// build a vector including this_item, and additional items that fit within j
				do_use = matrix[i - 1][j - all_foods[i-1]->kcal()];
				do_use.push_back(all_foods[i - 1]);
				// prefer whichever candidate has a greater total value
				int calDont, proDont, calDo, proDo;
				sum_food_vector(calDont, proDont, dont_use);
				sum_food_vector(calDo, proDo, do_use);
				if (proDont >= proDo) {
					matrix[i][j] = dont_use;
				}
				else {
					matrix[i][j] = do_use;
				}
			}
		}
	}
	
	// soln is a FoodVector that holds the solution
	soln = matrix[n][w];
	
	// convert soln to a unique_ptr<FoodVector> and return it
	for (int i = 0; i < soln.size(); i++) {
		solution->push_back(soln[i]);
	}
	
	return solution;
}

