///////////////////////////////////////////////////////////////////////////////
// maxprotein.hh
//
// Compute the set of foods that maximizes protein, within a calorie budget,
// with the greedy method or exhaustive search.
//
///////////////////////////////////////////////////////////////////////////////


#pragma once

#include <cassert>
#include <cmath>
#include <fstream>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

// One food item in the USDA database.
class Food {
private:
	// Human-readable description of the food, e.g. "all-purpose wheat
	// flour". Must be non-empty.
	std::string _description;

	// Human-readable description of the amount of the food in one
	// sample, e.g. "1 cup". Must be non-empty.
	std::string _amount;

	// Number of grams in one sample; must be non-negative.
	int _amount_g;

	// Energy, in units of kilocalories (commonly called "calories"), in
	// one sample; must be non-negative.
	int _kcal;

	// Number of grams of protein in one sample; most be non-negative.
	int _protein_g;

public:
	Food(const std::string& description,
		const std::string& amount,
		int amount_g,
		int kcal,
		int protein_g)
		: _description(description),
		_amount(amount),
		_amount_g(amount_g),
		_kcal(kcal),
		_protein_g(protein_g) {

		assert(!description.empty());
		assert(!amount.empty());
		assert(amount_g >= 0);
		assert(kcal >= 0);
		assert(protein_g >= 0);
	}

	const std::string& description() const { return _description; }
	const std::string& amount() const { return _amount; }
	int amount_g() const { return _amount_g; }
	int kcal() const { return _kcal; }
	int protein_g() const { return _protein_g; }

};

// Alias for a vector of shared pointers to Food objects.
using FoodVector = std::vector<std::shared_ptr<Food>>;

// Load all the valid foods from a USDA database in their ABBREV
// format. Foods that are missing fields such as the amount string are
// skipped. Returns nullptr on I/O error.
std::unique_ptr<FoodVector> load_usda_abbrev(const std::string& path) {

	std::unique_ptr<FoodVector> failure(nullptr);

	std::ifstream f(path);
	if (!f) {
		return failure;
	}

	std::unique_ptr<FoodVector> result(new FoodVector);

	for (std::string line; std::getline(f, line); ) {

		std::vector<std::string> fields;
		std::stringstream ss(line);
		for (std::string field; std::getline(ss, field, '^'); ) {
			fields.push_back(field);
		}

		/*if (fields.size() != 53) {
		return failure;
		}*/

		std::string descr_field = fields[1],
			kcal_field = fields[3],
			protein_g_field = fields[4],
			amount_g_field = fields[48],
			amount_field = fields[49];

		auto remove_tildes = [](std::string& output,
			const std::string& field) {
			if ((field.size() < 3) ||
				(field.front() != '~') ||
				(field.back() != '~')) {
				return false;
			}
			else {
				output.assign(field.begin() + 1, field.end() - 1);
				return true;
			}
		};

		auto parse_mil = [](int& output, const std::string& field) {
			std::stringstream ss(field);
			double floating;
			ss >> floating;
			if (!ss) {
				return false;
			}
			else {
				output = lround(floating);
				return true;
			}
		};

		std::string description, amount;
		int amount_g, kcal, protein_g;
		if (remove_tildes(description, descr_field) &&
			remove_tildes(amount, amount_field) &&
			parse_mil(amount_g, amount_g_field) &&
			parse_mil(kcal, kcal_field) &&
			parse_mil(protein_g, protein_g_field)) {
			result->push_back(std::shared_ptr<Food>(new Food(description,
				amount,
				amount_g,
				kcal,
				protein_g)));
		}
	}

	f.close();

	return result;
}

// Convenience function to compute the total kilocalories and protein
// in a FoodVector. Those values are returned through the
// first two pass-by-reference arguments.
void sum_food_vector(int& total_kcal,
	int& total_protein_g,
	const FoodVector& foods) {
	total_kcal = total_protein_g = 0;
	for (auto& food : foods) {
		total_kcal += food->kcal();
		total_protein_g += food->protein_g();
	}
}

// Convenience function to print out each food in a FoodVector,
// followed by the total kilocalories and protein in it.
void print_food_vector(const FoodVector& foods) {
	for (auto& food : foods) {
		std::cout << food->description()
			<< " (100 g where each " << food->amount()
			<< " is " << food->amount_g() << " g)"
			<< " kcal=" << food->kcal()
			<< " protein=" << food->protein_g() << " g"
			<< std::endl;
	}

	int total_kcal, total_protein_g;
	sum_food_vector(total_kcal, total_protein_g, foods);
	std::cout << "total kcal=" << total_kcal
		<< " total_protein=" << total_protein_g << " g"
		<< std::endl;
}

/*
filter_food_vector function: iterates through source vector, checks each elements kcal
against a min and max value and only pushes to the temp vector if conditions met. If the
target size is met, the loop breaks.
*/
std::unique_ptr<FoodVector> filter_food_vector(const FoodVector& source,
	int min_kcal,
	int max_kcal,
	int total_size) {

	std::unique_ptr<FoodVector> temp(new FoodVector);

	for (int i = 0; i < source.size(); i++)
		if (source[i]->kcal() >= min_kcal && source[i]->kcal() <= max_kcal) {
			temp->push_back(source[i]);

			if (temp->size() == total_size || temp->size() == 8500)
				break;
		}


	return temp;

}

/*
greedy_max_protein function: foods vector is copied onto a todo vector and an empty results
vector is created. The largest protein value is found in the todo vector and its index and
calories are stored. If the given calories and the running total result calories sum up to
below the target kcal, the element is pushed to the result vector and the calories are summed
the used element is then removed from the todo vector.
*/
std::unique_ptr<FoodVector> greedy_max_protein(const FoodVector& foods,
	int total_kcal) {


	FoodVector todo;

	for (int i = 0; i < foods.size(); i++)
		todo.push_back(foods[i]);

	std::unique_ptr<FoodVector> result(new FoodVector);

	int result_cal = 0;
	int calories = 0;

	while (!todo.empty()) {
		int index = 0;
		int max_protein = 0;

		for (int i = 0; i < todo.size(); i++) {
			if (max_protein < todo[i]->protein_g()) {
				max_protein = todo[i]->protein_g();
				calories = todo[i]->kcal();
				index = i;
			}
		}


		if (result_cal + calories <= total_kcal) {
			result->push_back(todo[index]);
			result_cal += calories;
		}
		todo.erase(todo.begin() + index);

	}
	return result;
}


/*
exhaustive_max_protein function: empty best vector is created. a for loop set to run 2^n - 1 times
Subsets are created from the foods vector. A candidate vector is created to store potential
subsets. sum_food_vector function called to sum up total proteins and kcal in the given vectors
if the candidate vector fits in the target kcal and is greater than the currently stored best vector,
the candidate vector is moved to the best vector.
*/

std::unique_ptr<FoodVector> exhaustive_max_protein(const FoodVector& foods,
	int total_kcal) {
	const int n = foods.size();
	assert(n < 64);
	std::unique_ptr<FoodVector> best(new FoodVector);

	FoodVector candidate;
	int calCandidate, pCandidate, calBest, pBest;

	for (int i = 0; i <= ((pow(2, n)) - 1); i++) {
		std::unique_ptr<FoodVector> candidatePtr(new FoodVector);
		candidate.clear();
		for (int j = 0; j <= n - 1; j++) {
			if (((i >> j) & 1) == 1) {
				candidate.push_back(foods[j]);
			}
		}
		for (int i = 0; i < candidate.size(); i++) {
			candidatePtr->push_back(candidate[i]);
		}
		sum_food_vector(calCandidate, pCandidate, *candidatePtr);
		sum_food_vector(calBest, pBest, *best);

		if (calCandidate <= total_kcal) {
			if (best == NULL || pCandidate > pBest) {
				best = std::move(candidatePtr);
			}
		}
	}
	return best;
}
