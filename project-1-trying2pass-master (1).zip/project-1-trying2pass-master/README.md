# Project 1: empirical analysis

Group members:

Cirjeffrey Baldomero  cirjeffrey92@gmail.com

Alessandro Quezada    sandroq95@gmail.com

Juan Carrera          juan_m_carrera@csu.fullerton.edu

Abstract
In this project you will implement and analyze three algorithms. For each algorithm, you will analyze that algorithm mathematically to derive a big-O complexity class; implement the algorithm in C++; analyze the algorithm empirically, by running it for various input sizes and plotting the timing data; and conclude whether the two analyses agree with each other.
The Hypothesis

This experiment will test the following hypothesis:

For large values of n, the mathematically-derived efficiency class of an algorithm accurately predicts the observed running time of an implementation of that algorithm.
