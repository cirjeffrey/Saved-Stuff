# project2
Project 2: greedy versus exhaustive

Group members:

Cirjeffrey Baldomero cirjeffrey92@gmail.com

Alessandro Quezada sandroq95@gmail.com

Juan Carrera juan_m_carrera@csu.fullerton.edu


Abstract
In this project you will implement and compare two algorithms that solve the same problem. The first is a greedy algorithm with a fast (i.e. polynomial) running time, while the second is an exhaustive search algorithm with a slow (i.e. exponential) running time.

Both algorithms solve the problem of planning a high-protein diet. More specifically, given a set of many food items available to eat, these algorithms pick a subset of foods that fit within a given calorie budget while maximizing protein content.
The Hypotheses
This experiment will test the following hypotheses:

  1.Exhaustive search algorithms are feasible to implement, and produce correct outputs.


  2.Algorithms with exponential running times are extremely slow, probably too slow to be of practical use.
  The Problem



Some people strive to make healthy food decisions by paying attention to nutritional content of their food. Our computational problem is inspired by this process. The premise of our problem is that a person wants to choose foods that maximize protein (measured in units of grams) while staying within a set calorie budget (measured in units of kilocalories, commonly called just “calories”). This problem can generalize to any other kind of dietary optimization; we could just as easily minimize fat within a calorie budget, maximize omega-3 acids within a calorie budget, minimize calories while meeting all vitamin requirements, and so on. We’re choosing protein somewhat arbitrarily to make this a concrete problem, and because calorie and protein data are both easily obtainable.
